import cv2

cap=cv2.VideoCapture(0)
cap.set(cv2.CAP_PROP_FRAME_WIDTH,1280)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT,720)

while True:
    _,frame=cap.read()
    hsv_frame=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
    height,width,_=frame.shape

    
    cx=int(width/2)
    cy=int(height/2)

    
    # Hassasiyeti artirmak icin tek piksel yerine 10x10'luk alanin ortalamasini aliyoruz
    roi = hsv_frame[cy-5:cy+5, cx-5:cx+5]
    avg_hsv = cv2.mean(roi)
    hue_value = avg_hsv[0]
    sat_value = avg_hsv[1]
    val_value = avg_hsv[2]

    color="Undefined"
    # Once Siyah ve Beyaz kontrolu (Doygunluk ve Parlaklik)
    if val_value < 40:
        color = "BLACK"
    elif sat_value < 40:
        color = "WHITE"
    else:
        # Renk tonuna gore siniflandirma (Renk sayisi artirildi)
        if hue_value < 5:
            color="RED"
        elif hue_value < 22:
            color="ORANGE"
        elif hue_value < 33:
            color="YELLOW"      
        elif hue_value < 78:
            color="GREEN"
        elif hue_value < 100:
            color="CYAN"
        elif hue_value < 131:
            color="BLUE"
        elif hue_value < 160:
            color="VIOLET"
        elif hue_value < 175:
            color="PINK"
        else:
            color="RED" 

    pixel_center_bgr=frame[cy,cx]
    b,g,r=int(pixel_center_bgr[0]),int(pixel_center_bgr[1]),int(pixel_center_bgr[2])

    cv2.rectangle(frame,(cx-220,10),(cx+200,120),(255,255,255),-1)
    cv2.putText(frame,color,(cx-200,100),0,3,(b,g,r),5)
    cv2.circle(frame,(cx,cy),5,(255,255,255),3)
    

    cv2.imshow("Frame",frame)
    key=cv2.waitKey(1)
    if key==27:
        break

cap.release()
cv2.destroyAllWindows()




    